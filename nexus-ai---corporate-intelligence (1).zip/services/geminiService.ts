import { GoogleGenAI, Type, Schema } from "@google/genai";
import { ChatMessage, AccountPlan, Source } from "../types";

const apiKey = process.env.API_KEY || '';

const getAIClient = () => new GoogleGenAI({ apiKey });

// System instruction for the chat agent - Enhanced for Nexus AI persona
const SYSTEM_INSTRUCTION = `
You are **Nexus AI**, a World-Class Corporate Research Analyst.
Your goal is to provide deep, comprehensive intelligence on companies to help users generate Account Plans.

WHEN RESEARCHING A COMPANY, YOU MUST COVER:
1. **Work Culture & People**: Internal environment, values, remote policies, and leadership style.
2. **Technology Stack**: Specific languages, cloud providers (AWS/Azure/GCP), frameworks, and legacy systems.
3. **Strategic Challenges**: What is difficult for them right now? (Regulation, technical debt, competition).
4. **Recent & Historical Data**: Compare current performance/strategy with the past (Old vs New Data).
5. **Financials**: Revenue trends, stock performance, funding rounds.

FORMATTING RULES:
- **ALWAYS use bold text** to highlight Key Metrics (e.g., **$5.2B Revenue**), Important Names (e.g., **Satya Nadella**), and Critical Challenges.
- Use distinct Markdown headers.
- Be professional, data-driven, yet conversational.

BEHAVIOR GUIDELINES:
- Use the 'googleSearch' tool for EVERY query to ensure real-time accuracy.
- If the user selects a company, provide a "Full 360 Degree View" immediately.
`;

export const sendChatMessage = async (
  history: ChatMessage[], 
  newMessage: string
): Promise<{ text: string; sources: Source[] }> => {
  const ai = getAIClient();
  
  const chatHistory = history.map(h => ({
    role: h.role,
    parts: [{ text: h.text }]
  }));

  const chat = ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      tools: [{ googleSearch: {} }]
    },
    history: chatHistory
  });

  const response = await chat.sendMessage({ message: newMessage });
  
  const text = response.text || "I couldn't generate a response.";
  
  const sources: Source[] = [];
  const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
  
  if (chunks) {
    chunks.forEach((chunk: any) => {
      if (chunk.web) {
        sources.push({
          title: chunk.web.title,
          uri: chunk.web.uri
        });
      }
    });
  }

  return { text, sources };
};

// Schema for the Detailed Account Plan
const accountPlanSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    profile: {
      type: Type.OBJECT,
      properties: {
        name: { type: Type.STRING },
        website: { type: Type.STRING },
        headquarters: { type: Type.STRING },
        foundedYear: { type: Type.STRING },
        founders: { type: Type.ARRAY, items: { type: Type.STRING } },
        industry: { type: Type.STRING },
        subIndustry: { type: Type.STRING },
        companyType: { type: Type.STRING },
        size: { type: Type.STRING },
        stockTicker: { type: Type.STRING, nullable: true }
      }
    },
    financials: {
      type: Type.OBJECT,
      properties: {
        revenue: { type: Type.STRING },
        growth: { type: Type.STRING },
        fundingRounds: { type: Type.STRING },
        majorInvestors: { type: Type.ARRAY, items: { type: Type.STRING } },
        keyMarkets: { type: Type.ARRAY, items: { type: Type.STRING } },
        mainProducts: { type: Type.ARRAY, items: { type: Type.STRING } },
        customerSegments: { type: Type.ARRAY, items: { type: Type.STRING } }
      }
    },
    strategy: {
      type: Type.OBJECT,
      properties: {
        vision: { type: Type.STRING },
        strategicPriorities: { type: Type.ARRAY, items: { type: Type.STRING } },
        challenges: { type: Type.ARRAY, items: { type: Type.STRING } },
        competition: { type: Type.STRING },
        risks: { type: Type.ARRAY, items: { type: Type.STRING } },
        opportunities: { type: Type.ARRAY, items: { type: Type.STRING } }
      }
    },
    culture: {
      type: Type.OBJECT,
      properties: {
        summary: { type: Type.STRING },
        values: { type: Type.ARRAY, items: { type: Type.STRING } },
        workModel: { type: Type.STRING },
        employeeSentiment: { type: Type.STRING },
        leadership: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              title: { type: Type.STRING },
              roleSummary: { type: Type.STRING }
            }
          }
        }
      }
    },
    technology: {
      type: Type.OBJECT,
      properties: {
        techStackOverview: { type: Type.STRING },
        languages: { type: Type.ARRAY, items: { type: Type.STRING } },
        cloudProviders: { type: Type.ARRAY, items: { type: Type.STRING } },
        databases: { type: Type.ARRAY, items: { type: Type.STRING } },
        devOpsTools: { type: Type.ARRAY, items: { type: Type.STRING } },
        securityStandards: { type: Type.ARRAY, items: { type: Type.STRING } }
      }
    },
    history: {
      type: Type.OBJECT,
      properties: {
        timeline: { type: Type.STRING },
        recentNews: { type: Type.ARRAY, items: { type: Type.STRING } },
        previousVsCurrentStrategy: { type: Type.STRING, description: "Comparison of old vs new strategies" }
      }
    },
    relationship: {
      type: Type.OBJECT,
      properties: {
        status: { type: Type.STRING },
        engagementNotes: { type: Type.STRING },
        nextSteps: { type: Type.ARRAY, items: { type: Type.STRING } }
      }
    },
    metadata: {
      type: Type.OBJECT,
      properties: {
        dataSources: { type: Type.ARRAY, items: { type: Type.STRING } },
        lastUpdated: { type: Type.STRING },
        confidenceScore: { type: Type.STRING },
        tags: { type: Type.ARRAY, items: { type: Type.STRING } }
      }
    }
  }
};

export const generateAccountPlan = async (chatHistory: ChatMessage[]): Promise<AccountPlan> => {
  const ai = getAIClient();
  
  const context = chatHistory.map(m => `${m.role.toUpperCase()}: ${m.text}`).join('\n');
  const prompt = `
    Based on the following research conversation, generate a comprehensive and structured Account Plan.
    You must populate ALL fields. If exact data is missing, make an educated inference based on the company size/industry and mark it in the metadata.
    Ensure important names and metrics are clearly identified in the string fields (you can use markdown bolding in string fields if appropriate).
    
    CONVERSATION HISTORY:
    ${context}
  `;

  // Using gemini-3-pro-preview for complex schema generation
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: accountPlanSchema
    }
  });

  const jsonText = response.text || "{}";
  try {
    return JSON.parse(jsonText) as AccountPlan;
  } catch (e) {
    console.error("Failed to parse Account Plan JSON", e);
    throw new Error("Could not generate a valid account plan.");
  }
};

export const updatePlanSection = async (
  currentContent: string, 
  instruction: string, 
  sectionName: string
): Promise<string> => {
  const ai = getAIClient();

  const prompt = `
    I have a JSON string representing the "${sectionName}" of an Account Plan.
    
    CURRENT JSON:
    ${currentContent}
    
    USER INSTRUCTION:
    ${instruction}
    
    Please rewrite this data to incorporate the user's instruction. 
    Return ONLY the valid JSON for this specific section.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
    config: { responseMimeType: "application/json" }
  });

  return response.text || currentContent;
};