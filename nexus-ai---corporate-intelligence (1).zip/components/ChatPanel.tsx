import React, { useState, useEffect, useRef } from 'react';
import { Send, Mic, StopCircle, Loader2, Link as LinkIcon, Bot, User, Sparkles, Building2, MessageSquare, Plus, Clock, Settings, Volume2, Square } from 'lucide-react';
import { ChatMessage, ResearchStatus, HistoryItem } from '../types';
import ReactMarkdown from 'react-markdown';

// --- Speech Recognition Types ---
interface SpeechRecognitionEvent {
  results: {
    [index: number]: {
      [index: number]: {
        transcript: string;
      };
      isFinal?: boolean;
    };
    length: number;
  };
  resultIndex: number;
}

interface SpeechRecognition {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: ((this: SpeechRecognition, ev: SpeechRecognitionEvent) => any) | null;
  onerror: ((this: SpeechRecognition, ev: any) => any) | null;
  onend: ((this: SpeechRecognition, ev: any) => any) | null;
  onstart: ((this: SpeechRecognition, ev: any) => any) | null;
}

interface WindowWithSpeech extends Window {
  SpeechRecognition: { new (): SpeechRecognition };
  webkitSpeechRecognition: { new (): SpeechRecognition };
}

// --- Typewriter Component ---
const Typewriter = ({ text, onComplete }: { text: string, onComplete?: () => void }) => {
  const [displayedText, setDisplayedText] = useState('');
  const [isComplete, setIsComplete] = useState(false);
  
  // Reset when text prop changes significantly (new message)
  useEffect(() => {
    setDisplayedText('');
    setIsComplete(false);
  }, [text]);

  useEffect(() => {
    if (isComplete) return;

    const words = text.split(' ');
    let index = 0;
    
    // If text is extremely short, just show it
    if (words.length <= 1) {
        setDisplayedText(text);
        setIsComplete(true);
        onComplete && onComplete();
        return;
    }

    const intervalId = setInterval(() => {
      if (index >= words.length) {
        clearInterval(intervalId);
        setIsComplete(true);
        onComplete && onComplete();
        return;
      }
      
      setDisplayedText((prev) => {
        const word = words[index];
        return prev + (prev ? ' ' : '') + word;
      });
      index++;
    }, 40); // 40ms per word

    return () => clearInterval(intervalId);
  }, [text, isComplete, onComplete]);

  return <ReactMarkdown>{displayedText}</ReactMarkdown>;
};

// --- Top IT Companies for Autocomplete ---
const TOP_COMPANIES = [
  "Microsoft", "Google (Alphabet)", "Amazon (AWS)", "Apple", "Meta (Facebook)",
  "NVIDIA", "Tesla", "Oracle", "Salesforce", "Adobe",
  "IBM", "Intel", "Cisco", "Netflix", "Spotify",
  "SAP", "ServiceNow", "Workday", "Snowflake", "Palantir",
  "Uber", "Airbnb", "Booking Holdings", "PayPal", "Square (Block)",
  "Zoom", "Atlassian", "Twilio", "Shopify", "Stripe",
  "Accenture", "Tata Consultancy Services (TCS)", "Infosys", "Wipro",
  "Capgemini", "Cognizant", "HCL Technologies", "Tech Mahindra", "Deloitte",
  "PwC", "Goldman Sachs", "JPMorgan Chase", "Visa", "Mastercard"
];

interface ChatPanelProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  status: ResearchStatus;
  historyItems: HistoryItem[];
  onNewChat: () => void;
}

const ChatPanel: React.FC<ChatPanelProps> = ({ messages, onSendMessage, status, historyItems, onNewChat }) => {
  const [input, setInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isSpeechSupported, setIsSpeechSupported] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const win = window as unknown as WindowWithSpeech;
      const SpeechRecognitionConstructor = win.SpeechRecognition || win.webkitSpeechRecognition;
      if (SpeechRecognitionConstructor) {
        const reco = new SpeechRecognitionConstructor();
        reco.continuous = false;
        reco.interimResults = false;
        reco.lang = 'en-US';
        
        reco.onresult = (event) => {
          let transcript = '';
          for (let i = event.resultIndex; i < event.results.length; ++i) {
             transcript += event.results[i][0].transcript;
          }
          if (transcript) {
            setInput(prev => {
                const needsSpace = prev.length > 0 && !prev.endsWith(' ');
                return prev + (needsSpace ? ' ' : '') + transcript;
            });
          }
        };

        reco.onstart = () => setIsListening(true);
        reco.onend = () => setIsListening(false);
        reco.onerror = (event: any) => {
          console.error("Speech recognition error:", event.error);
          setIsListening(false);
        };

        recognitionRef.current = reco;
        setIsSpeechSupported(true);
      }
    }

    return () => {
        if (recognitionRef.current) {
            recognitionRef.current.abort();
        }
        if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
            window.speechSynthesis.cancel();
        }
    };
  }, []);

  // --- Text to Speech Handler ---
  const handleSpeak = (text: string) => {
    if (!('speechSynthesis' in window)) {
        alert("Text-to-speech is not supported in this browser.");
        return;
    }
    
    window.speechSynthesis.cancel();
    
    const cleanText = text
      .replace(/\*\*/g, '')
      .replace(/#/g, '')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      .replace(/`|~/g, '')
      .replace(/\n/g, '. ');

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1;
    utterance.pitch = 1;
    
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
      if ('speechSynthesis' in window) {
          window.speechSynthesis.cancel();
          setIsSpeaking(false);
      }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInput(value);

    if (value.trim().length > 0) {
      const filtered = TOP_COMPANIES.filter(c => 
        c.toLowerCase().includes(value.toLowerCase())
      );
      setSuggestions(filtered.slice(0, 8));
      setShowSuggestions(true);
    } else {
      setShowSuggestions(false);
    }
  };

  const handleSuggestionClick = (company: string) => {
    const prompt = `Please provide a detailed deep-dive analysis on ${company}. Include their work culture, current vs old technology stack, detailed challenges, recent news, and financial history.`;
    submitMessage(prompt);
  };

  const toggleListening = () => {
    const reco = recognitionRef.current;
    if (!reco) {
        alert("Speech recognition not initialized or supported.");
        return;
    }

    if (isListening) {
      reco.stop();
    } else {
      try {
          reco.start();
      } catch (error) {
          console.error("Error starting speech recognition:", error);
      }
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, status]);

  const submitMessage = (text: string) => {
      onSendMessage(text);
      setInput('');
      setShowSuggestions(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || status === ResearchStatus.RESEARCHING) return;
    submitMessage(input);
  };

  const handleNewResearch = () => {
    onNewChat();
    setInput('');
  };

  return (
    <div className="flex h-full bg-zinc-900 border-r border-zinc-800 font-sans">
      
      {/* Sidebar Navigation */}
      <div className="w-64 hidden xl:flex flex-col bg-zinc-950 border-r border-zinc-800/50 pt-4 pb-4">
         <div className="px-4 mb-6">
            <button 
                onClick={handleNewResearch}
                className="w-full flex items-center gap-2 bg-zinc-900 hover:bg-zinc-800 text-white p-3 rounded-xl border border-zinc-800 transition-all text-sm font-medium shadow-sm"
            >
                <Plus className="w-4 h-4 text-indigo-400" /> New Research
            </button>
         </div>

         <div className="flex-1 px-4 overflow-y-auto">
            <div className="text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-3 pl-2">Recent Chats</div>
            <div className="space-y-1">
                {historyItems.map(item => (
                    <button key={item.id} className="w-full text-left p-2 rounded-lg hover:bg-zinc-900 text-zinc-400 hover:text-zinc-200 text-sm flex items-center gap-3 transition-colors group">
                        <MessageSquare className="w-4 h-4 text-zinc-600 group-hover:text-indigo-400 flex-shrink-0" />
                        <div className="flex flex-col min-w-0">
                             <span className="truncate font-medium">{item.title}</span>
                             <span className="text-[10px] text-zinc-600 truncate">{item.date}</span>
                        </div>
                    </button>
                ))}
                {historyItems.length === 0 && (
                    <div className="text-xs text-zinc-600 pl-2 italic">No recent history</div>
                )}
            </div>
         </div>

         <div className="px-4 mt-auto border-t border-zinc-800 pt-4">
            <button className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-zinc-900 text-zinc-400 hover:text-white transition-colors">
                <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-white font-bold text-xs">JD</div>
                <div className="text-left flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">John Doe</div>
                    <div className="text-xs text-zinc-500 truncate">Pro Plan</div>
                </div>
                <Settings className="w-4 h-4 text-zinc-600" />
            </button>
         </div>
      </div>

      {/* Main Chat Content */}
      <div className="flex-1 flex flex-col h-full bg-zinc-900 relative">
        {/* Header */}
        <div className="p-4 border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-md sticky top-0 z-10 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-zinc-100 flex items-center gap-2">
            <div className="bg-indigo-600 p-1.5 rounded-lg">
                <Sparkles className="w-4 h-4 text-white" />
            </div>
            Nexus AI
            </h2>
            <div className="flex items-center gap-3">
                {isSpeaking && (
                    <button 
                        onClick={stopSpeaking}
                        className="flex items-center gap-2 px-3 py-1.5 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded-full text-xs font-medium hover:bg-indigo-500/20 transition-colors animate-pulse"
                    >
                        <Square className="w-3 h-3 fill-current" /> Stop Speaking
                    </button>
                )}
                <div className="xl:hidden flex items-center gap-2 text-zinc-400">
                    <Clock className="w-4 h-4" />
                </div>
            </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6 scrollbar-thin scrollbar-thumb-zinc-700">
            {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-zinc-500 pb-20">
                <div className="w-20 h-20 bg-zinc-800 rounded-full flex items-center justify-center mb-6 shadow-xl shadow-black/20 animate-in zoom-in-50 duration-500">
                <Bot className="w-10 h-10 text-indigo-400" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-3">Nexus AI</h3>
                <p className="max-w-xs text-center text-sm mb-8 text-zinc-400">
                Deep corporate intelligence & strategic account planning at your fingertips.
                </p>
                
                <div className="grid grid-cols-1 gap-3 w-full max-w-sm">
                <button onClick={() => submitMessage("Research Microsoft's new AI strategy")} className="px-4 py-3 text-sm text-zinc-300 bg-zinc-800/50 hover:bg-zinc-800 rounded-xl border border-zinc-700/50 hover:border-zinc-600 transition-all flex items-center justify-between group">
                    Research Microsoft AI Strategy <Sparkles className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity text-indigo-400"/>
                </button>
                <button onClick={() => submitMessage("What is the work culture like at Netflix?")} className="px-4 py-3 text-sm text-zinc-300 bg-zinc-800/50 hover:bg-zinc-800 rounded-xl border border-zinc-700/50 hover:border-zinc-600 transition-all flex items-center justify-between group">
                    Netflix Work Culture Analysis <Sparkles className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity text-indigo-400"/>
                </button>
                </div>
            </div>
            )}
            
            {messages.map((msg, idx) => (
            <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] sm:max-w-[75%] rounded-3xl px-5 py-4 shadow-sm ${
                msg.role === 'user' 
                    ? 'bg-zinc-800 text-white rounded-br-sm' 
                    : 'bg-transparent text-zinc-300 rounded-bl-sm -ml-2'
                }`}>
                <div className="flex items-center justify-between gap-4 mb-2 opacity-60">
                    <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider font-semibold">
                        {msg.role === 'user' ? (
                        <><User className="w-3 h-3" /> You</>
                        ) : (
                        <><Bot className="w-3 h-3 text-indigo-400" /> Nexus AI</>
                        )}
                    </div>
                    {msg.role === 'model' && (
                        <button 
                            onClick={() => handleSpeak(msg.text)}
                            className="p-1 hover:text-indigo-400 transition-colors rounded hover:bg-zinc-800"
                            title="Read Aloud"
                        >
                            <Volume2 className="w-3 h-3" />
                        </button>
                    )}
                </div>
                
                <div className={`prose prose-sm prose-invert max-w-none leading-relaxed`}>
                    {/* Only use typewriter for the last message if it's from the model and we are NOT currently researching (meaning it's done) */}
                    {msg.role === 'model' && idx === messages.length - 1 && status === ResearchStatus.IDLE ? (
                        <Typewriter text={msg.text} onComplete={scrollToBottom} />
                    ) : (
                        <ReactMarkdown>{msg.text}</ReactMarkdown>
                    )}
                </div>

                {msg.sources && msg.sources.length > 0 && (
                    <div className="mt-5 pt-3 border-t border-zinc-800/50">
                    <p className="text-[10px] font-bold text-zinc-500 mb-2 uppercase tracking-wider flex items-center gap-1">
                        <LinkIcon className="w-3 h-3" /> Sources
                    </p>
                    <div className="flex flex-wrap gap-2">
                        {msg.sources.map((source, sIdx) => (
                        <a 
                            key={sIdx}
                            href={source.uri}
                            target="_blank"
                            rel="noreferrer"
                            className="text-[10px] truncate max-w-[150px] px-2 py-1 rounded-full bg-zinc-800 hover:bg-zinc-700 text-indigo-300 border border-zinc-700 transition-colors"
                            title={source.title}
                        >
                            {source.title || new URL(source.uri).hostname}
                        </a>
                        ))}
                    </div>
                    </div>
                )}
                </div>
            </div>
            ))}
            
            {status === ResearchStatus.RESEARCHING && (
            <div className="flex justify-start">
                <div className="flex items-center gap-3 px-5 py-3 bg-zinc-800 rounded-3xl rounded-bl-sm -ml-2 border border-zinc-700/50">
                <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />
                <span className="text-sm text-zinc-400 animate-pulse">Nexus AI is thinking...</span>
                </div>
            </div>
            )}
            <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 bg-zinc-900 sticky bottom-0 z-20">
            <div className="relative max-w-3xl mx-auto">
            
            {/* ChatGPT-style Autocomplete "Up-Down Box" */}
            {showSuggestions && suggestions.length > 0 && (
                <div className="absolute bottom-full left-0 w-full mb-3 bg-zinc-800 border border-zinc-700 rounded-2xl shadow-2xl overflow-hidden z-50 transform origin-bottom animate-in fade-in slide-in-from-bottom-2">
                <div className="px-4 py-2 text-[10px] font-bold text-zinc-500 bg-zinc-900/50 uppercase tracking-wider border-b border-zinc-700/50">
                    Suggested Companies
                </div>
                <div className="max-h-60 overflow-y-auto scrollbar-thin scrollbar-thumb-zinc-600">
                    {suggestions.map((company) => (
                        <button
                        key={company}
                        onClick={() => handleSuggestionClick(company)}
                        className="w-full text-left px-4 py-3 text-sm text-zinc-300 hover:bg-zinc-700 hover:text-white transition-colors flex items-center gap-3 border-b border-zinc-700/30 last:border-0"
                        >
                        <div className="w-8 h-8 rounded-full bg-zinc-900 flex items-center justify-center flex-shrink-0 text-indigo-400">
                            <Building2 className="w-4 h-4" />
                        </div>
                        <div>
                            <div className="font-medium">{company}</div>
                            <div className="text-[10px] text-zinc-500">Generate deep-dive report</div>
                        </div>
                        </button>
                    ))}
                </div>
                </div>
            )}

            <form onSubmit={handleSubmit} className="relative bg-zinc-800 border border-zinc-700 rounded-3xl shadow-lg focus-within:border-indigo-500/50 focus-within:ring-2 focus-within:ring-indigo-500/20 transition-all">
                <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={handleInputChange}
                onFocus={() => { if(input) setShowSuggestions(true) }}
                placeholder="Ask Nexus AI about a company..."
                className="w-full pl-5 pr-24 py-4 bg-transparent text-white placeholder-zinc-500 focus:outline-none rounded-3xl"
                disabled={status === ResearchStatus.RESEARCHING}
                autoComplete="off"
                />
                
                <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                {isSpeechSupported && (
                    <button
                    type="button"
                    onClick={toggleListening}
                    className={`p-2 rounded-full transition-colors ${
                        isListening ? 'text-red-400 bg-red-900/20 animate-pulse' : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-700'
                    }`}
                    title={isListening ? "Stop Listening" : "Start Listening"}
                    >
                    {isListening ? <StopCircle className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                    </button>
                )}
                <button
                    type="submit"
                    disabled={!input.trim() || status === ResearchStatus.RESEARCHING}
                    className="p-2 bg-indigo-600 text-white rounded-full hover:bg-indigo-500 disabled:opacity-50 disabled:bg-zinc-700 disabled:cursor-not-allowed transition-all shadow-lg shadow-indigo-600/20"
                >
                    <Send className="w-4 h-4" />
                </button>
                </div>
            </form>
            <div className="text-center mt-3 text-[10px] text-zinc-600">
                Nexus AI uses advanced models. Verify critical financial data.
            </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default ChatPanel;